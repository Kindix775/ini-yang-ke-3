package com.inventaris.controller;

import com.inventaris.dao.BarangDAO;
import com.inventaris.dao.BorrowDAO;
import com.inventaris.model.Barang;
import com.inventaris.model.Borrow;
import com.inventaris.model.User;
import com.inventaris.util.SessionManager;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class DashboardController implements Initializable {

    // --- UI STATISTIK (Sesuai FXML Home/Dashboard) ---
    @FXML private Label totalBarangLabel;
    @FXML private Label tersediaLabel;
    @FXML private Label dipinjamLabel;
    @FXML private Label overdueLabel;
    @FXML private Label welcomeLabel; // Opsional, jika ada di dalam konten

    // --- TABEL PEMINJAMAN TERBARU ---
    @FXML private TableView<Borrow> recentBorrowTable;
    @FXML private TableColumn<Borrow, String> colPeminjam;
    @FXML private TableColumn<Borrow, String> colBarang;
    @FXML private TableColumn<Borrow, String> colTglPinjam;
    @FXML private TableColumn<Borrow, String> colDeadline;
    @FXML private TableColumn<Borrow, String> colStatus;

    // --- LOGIC TOOLS ---
    private final SessionManager sessionManager = SessionManager.getInstance();
    private final BarangDAO barangDAO = new BarangDAO();
    private final BorrowDAO borrowDAO = new BorrowDAO();
    private Timeline refreshTimeline;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Cek User
        User currentUser = sessionManager.getCurrentUser();
        if (currentUser != null && welcomeLabel != null) {
            welcomeLabel.setText("Selamat Datang, " + currentUser.getNama());
        }

        // 2. Load Data Awal
        loadDashboardStatistics();
        loadRecentBorrows();

        // 3. Jalankan Auto Refresh (Setiap 5 detik)
        startAutoRefresh();

        System.out.println("✅ Konten Dashboard berhasil dimuat.");
    }

    // =========================================================
    // LOGIKA DATA (DAO)
    // =========================================================

    private void loadDashboardStatistics() {
        try {
            List<Barang> allBarang = barangDAO.getAll();
            
            int total = allBarang.size();
            int tersedia = (int) allBarang.stream()
                .filter(b -> b.getJumlahTersedia() > 0 && "tersedia".equals(b.getStatus()))
                .count();
            
            List<Borrow> activeBorrows = borrowDAO.getActiveBorrows();
            int dipinjam = activeBorrows.size();
            
            List<Borrow> overdueBorrows = borrowDAO.getOverdueBorrows();
            int overdue = overdueBorrows.size();
            
            // Update UI (Gunakan Platform.runLater jika dipanggil dari Thread lain)
            if (totalBarangLabel != null) totalBarangLabel.setText(String.valueOf(total));
            if (tersediaLabel != null) tersediaLabel.setText(String.valueOf(tersedia));
            if (dipinjamLabel != null) dipinjamLabel.setText(String.valueOf(dipinjam));
            if (overdueLabel != null) overdueLabel.setText(String.valueOf(overdue));
            
        } catch (Exception e) {
            System.err.println("Gagal memuat statistik: " + e.getMessage());
        }
    }

    private void loadRecentBorrows() {
        try {
            List<Borrow> borrows;
            
            // Logika filter berdasarkan role
            if (sessionManager.isAdmin()) {
                borrows = borrowDAO.getActiveBorrows();
            } else if (sessionManager.isPeminjam()) {
                Integer peminjamId = sessionManager.getCurrentRoleId();
                if (peminjamId != null) {
                    borrows = borrowDAO.getByPeminjamId(peminjamId).stream()
                        .filter(b -> "dipinjam".equals(b.getStatusBarang()))
                        .collect(Collectors.toList());
                } else {
                    borrows = new ArrayList<>();
                }
            } else {
                // Default fallback
                borrows = new ArrayList<>();
            }
            
            // Ambil 10 data terbaru saja
            if (borrows.size() > 10) {
                borrows = borrows.subList(0, 10);
            }
            
            ObservableList<Borrow> data = FXCollections.observableArrayList(borrows);
            if (recentBorrowTable != null) {
                recentBorrowTable.setItems(data);
            }

        } catch (Exception e) {
            System.err.println("Gagal memuat tabel recent: " + e.getMessage());
        }
    }

    // =========================================================
    // EVENT HANDLER (INTERAKSI DI DALAM KONTEN)
    // =========================================================

    /**
     * Menangani klik pada kotak Rekomendasi Barang di Home.fxml
     * Penting: Parameter harus (MouseEvent event) agar sesuai dengan FXML
     */
    @FXML
    private void handleBarang(MouseEvent event) {
        System.out.println("📦 Kotak rekomendasi barang diklik!");
        // Disini kamu bisa menambahkan logika untuk membuka detail barang
        // Karena navigasi ada di LayoutController, untuk sementara print saja dulu.
    }

    // =========================================================
    // UTILITIES (AUTO REFRESH)
    // =========================================================

    private void startAutoRefresh() {
        refreshTimeline = new Timeline(new KeyFrame(
            Duration.seconds(5),
            event -> {
                loadDashboardStatistics();
                loadRecentBorrows();
            }
        ));
        refreshTimeline.setCycleCount(Timeline.INDEFINITE);
        refreshTimeline.play();
    }

    // Wajib dipanggil saat halaman diganti agar tidak memakan memori
    public void stopAutoRefresh() {
        if (refreshTimeline != null) {
            refreshTimeline.stop();
        }
    }
}