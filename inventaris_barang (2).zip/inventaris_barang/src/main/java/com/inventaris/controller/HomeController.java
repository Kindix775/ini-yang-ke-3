package com.inventaris.controller;

import com.inventaris.Main;
import com.inventaris.util.SessionManager;
import com.inventaris.util.AlertUtil;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;


public class HomeController {

    @FXML private TextField searchField;
    @FXML private Button logoutBtn;
    @FXML private Button btnDashboard;
    @FXML private Button btnBarang;
    @FXML private Button btnPeminjaman;
    @FXML private Button btnLaporan;
    @FXML private Button btnLogout;
    @FXML private Button btnUser;
    @FXML private BorderPane rootPane;
    @FXML private TextField txtSearch;
    
    private DataBarangPeminjamController dataBarangController;
    private Parent dataBarangPage;

    private final SessionManager sessionManager = SessionManager.getInstance();

    
   
    
    
    @FXML
public void initialize() {
    String role = sessionManager.getCurrentUser().getRole();
    
   
    
    System.out.println("Home screen loaded");
}

private void configureMenuByRole(String role) {
    switch (role) {
        case "admin":
            btnUser.setVisible(true);
            btnUser.setManaged(true);
            break;
            
        case "peminjam":
        case "instansi":
            btnUser.setVisible(false);
            btnUser.setManaged(false); // ✅ Penting: juga set managed ke false agar tidak memakan space
            break;
            
        default:
            btnUser.setVisible(false);
            btnUser.setManaged(false);
    }
}
    
    @FXML
private void handleDashboard() {
    Main.showMainLayout();
}

 @FXML
private void handleSearch() {
    String keyword = txtSearch.getText().trim();
    if (keyword.isEmpty()) return;

    try {
        if (dataBarangController == null) {
            // Load DataBarang.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/DataBarang.fxml"));

            dataBarangPage = loader.load();

            // Dapatkan controller
            dataBarangController = loader.getController();
        }

        // Set halaman ke center BorderPane
        rootPane.setCenter(dataBarangPage);

        // Jalankan filter
        dataBarangController.searchBarang(keyword);

    } catch (IOException e) {
        e.printStackTrace();
    }
}


    @FXML
    private void handlePeminjaman() {
        Main.loadContent("Peminjaman.fxml");
    }

    @FXML
    private void handleLaporan() {
        Main.loadContent("Laporan.fxml");
    }

    @FXML
    private void handleBarang() {
        Main.loadContent("DataBarang.fxml");
    }
    
    @FXML
    private void handleUser() {
      
        Main.loadContent("User.fxml");
    }

    @FXML
    private void handleLogout() {
        if (AlertUtil.showLogoutConfirmation()) {
            sessionManager.logout();
            Main.showLoginScreen();
        }
    }
}
