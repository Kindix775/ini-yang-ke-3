package com.inventaris.controller;

import com.inventaris.Main;
import com.inventaris.model.User;
import com.inventaris.util.AlertUtil;
import com.inventaris.util.LogActivityUtil;
import com.inventaris.util.SessionManager;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LayoutController implements Initializable {

    // --- Header UI ---
    @FXML private Circle profileImage;
    @FXML private Label welcomeLabel;
    @FXML private Label roleLabel;

    // --- Navigation UI ---
    @FXML private Button btnDashboard;
    @FXML private Button btnLapor;
    @FXML private Button btnPeminjaman;
    @FXML private Button btnLaporan;
    @FXML private Button btnBarang;
    @FXML private Button btnUser;
    @FXML private Button btnBerita;
    
    
    private String lastLoadedFxml = "/fxml/Dashboard.fxml";
    
    // String style agar kodingan lebih rapi dan tidak panjang ke samping
private final String DEFAULT_STYLE = "-fx-background-color: #D9CBC1; -fx-background-radius: 25; -fx-font-weight: bold; -fx-font-size: 16px; -fx-cursor: hand;";
private final String ACTIVE_STYLE = "-fx-background-color: #8C6E63; -fx-text-fill: white; -fx-background-radius: 25; -fx-font-weight: bold; -fx-font-size: 16px;";
    
    // --- Search & Content ---
    @FXML private TextField txtSearch;
    @FXML private StackPane contentArea; // Area dinamis (tambahkan ini di FXML)
    private static LayoutController instance;
    // --- Utilities ---
    private final SessionManager sessionManager = SessionManager.getInstance();
    private Parent currentContent;

    
    public static LayoutController getInstance() {
        return instance;
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Validasi Sesi
        
        instance = this;
        
        User currentUser = sessionManager.getCurrentUser();
        if (currentUser == null) {
            AlertUtil.showError("Error", "Session tidak valid!");
            handleLogout();
            return;
        }

        // 2. Set Informasi User di Header
        welcomeLabel.setText("Halo, " + currentUser.getNama());
        roleLabel.setText(getRoleDisplayName(currentUser.getRole()));

        // 3. Atur Menu Berdasarkan Role (Logika dari referensi)
        configureMenuByRole(currentUser.getRole());

        // 4. Load Halaman Default (Dashboard/Home)
        handleHome();
        
        System.out.println("✅ Layout initialized for: " + currentUser.getUsername());
    }

    // =================================================================
    // NAVIGASI MENU
    // =================================================================

    
    @FXML
    private void handleHome() {
        setActiveMenu(btnDashboard);
        resetAllMenus();
        loadPage("/fxml/Dashboard.fxml"); // Pastikan file ini berisi Statistik & Tabel Recent
    }

    @FXML
    private void handleDashboard() {
        setActiveMenu(btnDashboard);
        loadPage("/fxml/Home.fxml"); // Pastikan file ini berisi Statistik & Tabel Recent
    }

    @FXML
    public void handlePeminjaman() {
        setActiveMenu(btnPeminjaman);
        loadPage("/fxml/Peminjaman.fxml");
    }

    @FXML
    private void handleLaporan() {
        setActiveMenu(btnLaporan);
        loadPage("/fxml/LaporanPeminjam.fxml");
    }
    
    @FXML
    private void handleLapor() {
        setActiveMenu(btnLapor);
        loadPage("/fxml/LaporanAdmin.fxml");
    }

    @FXML
    private void handleBarang() {
        setActiveMenu(btnBarang);
        loadPage("/fxml/DataBarang.fxml");
    }

    @FXML
    private void handleUser() {
        setActiveMenu(btnUser);
        loadPage("/fxml/User.fxml");
    }

    @FXML
    private void handleBerita() {
        setActiveMenu(btnBerita);
        loadPage("/fxml/Laporan.fxml");
    }
    // =================================================================
    // LOGIKA PENCARIAN (Smart Search)
    // =================================================================

    @FXML
    private void handleSearch() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) return;

        System.out.println("🔍 Searching: " + keyword);

        try {
            // Kita paksa pindah ke halaman Data Barang untuk melakukan pencarian
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/DataBarang.fxml"));
            Parent page = loader.load();
            
            // Ambil controller dari halaman DataBarang
            // Asumsi: Kamu punya method searchBarang() di DataBarangController
            Object controller = loader.getController();
            
            // Menggunakan Refleksi atau Casting jika kamu punya kelas DataBarangController
            if (controller instanceof DataBarangPeminjamController) {
                ((DataBarangPeminjamController) controller).searchBarang(keyword);
            } 
            // else if (controller instanceof AdminBarangController) { ... }

            // Tampilkan halaman dan update tombol aktif
            contentArea.getChildren().clear();
            contentArea.getChildren().add(page);
            setActiveMenu(btnBarang); // Highlight tombol Barang

        } catch (IOException e) {
            e.printStackTrace();
            AlertUtil.showError("Error", "Gagal melakukan pencarian.");
        }
    }

    

// 1. Fungsi khusus untuk Mereset SEMUA tombol ke warna asal
private void resetAllMenus() {
    btnDashboard.setStyle(DEFAULT_STYLE);
    btnPeminjaman.setStyle(DEFAULT_STYLE);
    btnLaporan.setStyle(DEFAULT_STYLE);
    btnBarang.setStyle(DEFAULT_STYLE);
    btnUser.setStyle(DEFAULT_STYLE);
    btnBerita.setStyle(DEFAULT_STYLE);
    btnLapor.setStyle(DEFAULT_STYLE);
}

// 2. Modifikasi setActiveMenu agar memanggil fungsi reset di atas
private void setActiveMenu(Button activeButton) {
    // Reset dulu semuanya
    resetAllMenus();

    // Baru warnai tombol yang aktif
    if (activeButton != null) {
        activeButton.setStyle(ACTIVE_STYLE);
    }
}


    
    
    // =================================================================
    // LOGIKA UTILITAS & LOGOUT
    // =================================================================

    @FXML
    private void handleLogout() {
        if (AlertUtil.showLogoutConfirmation()) {
            User currentUser = sessionManager.getCurrentUser();
            if (currentUser != null) {
                LogActivityUtil.logLogout(currentUser.getUsername(), currentUser.getRole());
            }
            
            sessionManager.logout();
            
            // Kembali ke Login Screen (memanggil method static di Main)
            try {
                Main.showLoginScreen(); // Pastikan method ini ada di Main.java
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
  

    // Fungsi RAHASIA untuk mengganti konten di tengah
    @FXML
    private void handleRefresh() {
        System.out.println("🔄 Refreshing page: " + lastLoadedFxml);
        
        // Animasi loading kecil (opsional/logika reload)
        loadPage(lastLoadedFxml);
        
        // Jika sedang di halaman barang & ada search text, kosongkan search text agar terlihat seperti reset
        if (txtSearch != null) {
            txtSearch.clear();
        }
    }

    // 3. UPDATE METHOD LOADPAGE (PENTING!)
    // Kita harus update lastLoadedFxml setiap kali ganti halaman
    private void loadPage(String fxmlPath) {
        try {
            // Simpan path halaman ini agar bisa direfresh nanti
            this.lastLoadedFxml = fxmlPath; 

            contentArea.getChildren().clear();
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            currentContent = loader.load();
            contentArea.getChildren().add(currentContent);
        } catch (IOException e) {
            System.err.println("❌ Gagal memuat halaman: " + fxmlPath);
            e.printStackTrace();
        }
    }

    

    private void configureMenuByRole(String role) {
        // Default: Sembunyikan semua dulu agar aman
        btnBarang.setVisible(false); btnBarang.setManaged(false);
        btnPeminjaman.setVisible(false); btnPeminjaman.setManaged(false);
        btnLaporan.setVisible(false); btnLaporan.setManaged(false);
        btnUser.setVisible(false); btnUser.setManaged(false);//buat admin doang
        btnLapor.setVisible(false); btnLapor.setManaged(false); //buat admin doang
        btnBerita.setVisible(false); btnBerita.setManaged(false); //buat admin doang

        switch (role) {
            case "admin":
                btnBerita.setVisible(true); btnBerita.setManaged(true);
                btnUser.setVisible(true); btnUser.setManaged(true);
                btnLapor.setVisible(true); btnLapor.setManaged(true);
                break;
            case "peminjam":
               btnBarang.setVisible(true); btnBarang.setManaged(true);
               btnPeminjaman.setVisible(true); btnPeminjaman.setManaged(true);
               btnLaporan.setVisible(true); btnLaporan.setManaged(true);
            case "instansi":
                btnBarang.setVisible(true); btnBarang.setManaged(true);
                btnPeminjaman.setVisible(true); btnPeminjaman.setManaged(true);
                btnLapor.setVisible(true); btnLaporan.setManaged(true);
                break;
        }
    }

    private String getRoleDisplayName(String role) {
        switch (role) {
            case "admin": return "Administrator";
            case "peminjam": return "Peminjam";
            case "instansi": return "Instansi";
            default: return role;
        }
    }
}